package com.example.android.tflitecamerademo;

import android.app.Activity;

public class RegisterActivity extends Activity {
}
